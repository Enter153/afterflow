#pragma once

// Independently testable picker for Afterflow's configurable random tick stage.
// Zero is an explicit choice: it means raw / unbuffered input.
#include <algorithm>
#include <cctype>
#include <random>
#include <string>
#include <vector>

namespace afterflow_random {

inline std::vector<int> parseTickOptions(std::string const& configured) {
    std::vector<int> ticks;
    size_t begin = 0;
    while (begin <= configured.size()) {
        auto separator = configured.find(',', begin);
        auto token = configured.substr(begin, separator == std::string::npos ?
            std::string::npos : separator - begin);
        auto first = token.find_first_not_of(" \t\r\n");
        if (first != std::string::npos) {
            auto last = token.find_last_not_of(" \t\r\n");
            token = token.substr(first, last - first + 1);
            try {
                size_t parsed = 0;
                auto value = std::stoi(token, &parsed, 10);
                if (parsed == token.size() && value >= 0 && value <= 240 &&
                    std::find(ticks.begin(), ticks.end(), value) == ticks.end()) {
                    ticks.push_back(value);
                }
            }
            catch (std::exception const&) {
                // Ignore malformed or out-of-range entries.
            }
        }
        if (separator == std::string::npos) {
            break;
        }
        begin = separator + 1;
    }
    // Never leave Random unusable because of a typo in mod settings.
    if (ticks.empty()) {
        return { 2, 4, 0 };
    }
    return ticks;
}

inline int drawTick(std::string const& configured) {
    auto ticks = parseTickOptions(configured);
    static std::mt19937 randomEngine { std::random_device{}() };
    std::uniform_int_distribution<size_t> distribution(0, ticks.size() - 1);
    return ticks[distribution(randomEngine)];
}

} // namespace afterflow_random
