#!/usr/bin/env python3
"""Add configurable per-press random tick stage to upstream Afterflow v2.1.6.

Usage: python apply_random_stage.py /path/to/afterflow-repo

Requires unmodified source matching the public Afterflow v2.1.6 main.cpp.
Never attempts to binary-patch a DLL or silently replaces an installed mod.
"""
import json
import pathlib
import shutil
import sys

BASE = pathlib.Path(__file__).resolve().parent


def replace_once(text, needle, replacement, description):
    count = text.count(needle)
    if count != 1:
        raise ValueError(f"{description}: expected 1 source match, got {count}; source may have changed")
    return text.replace(needle, replacement, 1)


def make_updated_source(original):
    source = original
    source = replace_once(
        source,
        '#include <Geode/modify/RingObject.hpp>\n',
        '#include <Geode/modify/RingObject.hpp>\n#include "random_tick_picker.hpp"\n',
        'include picker',
    )
    source = replace_once(
        source,
        '        { false, 0, 0, false },\n    };\n    constexpr int STAGE_TABLE_SIZE = sizeof(STAGE_TABLE) / sizeof(STAGE_TABLE[0]);',
        '        { false, 0, 0, false },\n'
        '        { true, 2, 2, true }, // Random per physical press\n'
        '    };\n'
        '    constexpr int STAGE_TABLE_SIZE = sizeof(STAGE_TABLE) / sizeof(STAGE_TABLE[0]);\n'
        '    constexpr int RANDOM_STAGE_INDEX = STAGE_TABLE_SIZE - 1;',
        'new random stage',
    )
    old_apply = '''    void applyStage() {
        auto const& stageDefinition = STAGE_TABLE[state.stageIndex];
        state.isEnabled = stageDefinition.isEnabled;
        state.ticksAllModes = stageDefinition.ticksAllModes;
        state.ticksWaveMode = stageDefinition.ticksWaveMode;
    }

    std::string stageText() {
'''
    new_apply = '''    void applyRandomTickChoice(int chosenTicks) {
        // A 0-tick draw means no prediction for this press and its release.
        state.isEnabled = chosenTicks != 0;
        state.ticksAllModes = chosenTicks;
        state.ticksWaveMode = chosenTicks;
    }
    int drawConfiguredRandomTicks() {
        // Read each time so options edited in Geode's menu take effect immediately.
        return afterflow_random::drawTick(
            Mod::get()->getSettingValue<std::string>("random-tick-options"));
    }
    void applyStage() {
        auto const& stageDefinition = STAGE_TABLE[state.stageIndex];
        if (stageDefinition.isCustom) {
            applyRandomTickChoice(drawConfiguredRandomTicks());
            return;
        }
        state.isEnabled = stageDefinition.isEnabled;
        state.ticksAllModes = stageDefinition.ticksAllModes;
        state.ticksWaveMode = stageDefinition.ticksWaveMode;
    }

    std::string stageText() {
'''
    source = replace_once(source, old_apply, new_apply, 'stage application')
    source = replace_once(
        source,
        '''    std::string stageText() {
        if (!state.isEnabled) {
''',
        '''    std::string stageText() {
        if (state.stageIndex == RANDOM_STAGE_INDEX) {
            return state.isEnabled
                ? fmt::format("random: {} ticks", state.ticksAllModes)
                : "random: 0 ticks (raw input)";
        }
        if (!state.isEnabled) {
''',
        'random mode text',
    )
    source = replace_once(
        source,
        '''    std::string stageBanner() {
        if (!state.isEnabled) {
''',
        '''    std::string stageBanner() {
        if (state.stageIndex == RANDOM_STAGE_INDEX) {
            return fmt::format("stage {}: random per click | now {} | choices: {}",
                state.stageIndex + 1, stageText(),
                Mod::get()->getSettingValue<std::string>("random-tick-options"));
        }
        if (!state.isEnabled) {
''',
        'random mode banner',
    )
    source = replace_once(
        source,
        '''    void handleButton(bool isDown, int buttonId, bool isFirstPlayer) {
        if (!state.isSimulating && buttonId == 1 && !state.isInjecting) {
            auto* player1 = this->m_player1;
''',
        '''    void handleButton(bool isDown, int buttonId, bool isFirstPlayer) {
        if (!state.isSimulating && buttonId == 1 && !state.isInjecting) {
            // Pick once per physical press (not on release, ghost input, or replayed input).
            // Keep the selected tick value through this press's release.
            auto* activePlayLayer = GameManager::get()->m_playLayer;
            if (isDown && !state.hasRealInput && state.stageIndex == RANDOM_STAGE_INDEX &&
                activePlayLayer && !activePlayLayer->m_isPaused) {
                int chosenTicks = drawConfiguredRandomTicks();
                if (chosenTicks == 0 && !state.queuedInputs.empty()) {
                    // Do not let previously delayed events fire after switching to raw input.
                    resetPending();
                    if (state.hasAppliedInput != state.hasRealInput) {
                        sendButton(activePlayLayer, state.hasRealInput);
                    }
                }
                applyRandomTickChoice(chosenTicks);
            }
            auto* player1 = this->m_player1;
''',
        'input hook',
    )
    source = replace_once(
        source,
        'say("{} cycles anywhere: 2/2 -> 4/4 -> 8/8 -> 16/8 -> 24/12 -> 32/16 -> 40/20 -> off", stageKey());',
        'say("{} cycles anywhere: 2/2 -> 4/4 -> 8/8 -> 16/8 -> 24/12 -> 32/16 -> 40/20 -> off -> random per click", stageKey());',
        'cycle help text',
    )
    return source


def main():
    if len(sys.argv) != 2:
        sys.exit("Usage: python apply_random_stage.py /path/to/afterflow-repo")
    root = pathlib.Path(sys.argv[1]).expanduser().resolve()
    source_path = root / 'src' / 'main.cpp'
    manifest_path = root / 'mod.json'
    if not source_path.is_file() or not manifest_path.is_file():
        sys.exit("Missing src/main.cpp or mod.json. Supply the extracted/checked-out Afterflow source directory.")
    original = source_path.read_text(encoding='utf-8')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest.get('id') != 'afterflow.prsevend':
        sys.exit('This does not look like Afterflow.')
    if 'random-tick-options' in manifest['settings'] or 'random_tick_picker.hpp' in original:
        sys.exit('Random stage already appears installed; no files changed.')
    try:
        updated_source = make_updated_source(original)
    except ValueError as e:
        sys.exit(f'Nothing changed: {e}')

    # Place it just before the keybind section in Geode's mod menu.
    modified_settings = {}
    for key, value in manifest['settings'].items():
        if key == 'keybinds-title':
            modified_settings['random-title'] = {
                'type': 'title',
                'name': 'Random per click',
                'description': 'Options for the random tick stage selected with F6',
            }
            modified_settings['random-tick-options'] = {
                'type': 'string',
                'name': 'Random tick options',
                'description': 'Comma-separated tick values, 0-240. Example: 4,2,0 or 16,32. '
                               '0 means raw input. Picks a random option on each press.',
                'default': '2,4,0',
            }
        modified_settings[key] = value
    manifest['settings'] = modified_settings

    source_path.with_suffix('.cpp.bak').write_text(original, encoding='utf-8')
    manifest_path.with_suffix('.json.bak').write_text(manifest_path.read_text(encoding='utf-8'), encoding='utf-8')
    source_path.write_text(updated_source, encoding='utf-8')
    manifest_path.write_text(json.dumps(manifest, indent=4, ensure_ascii=False) + '\n', encoding='utf-8')
    shutil.copy2(BASE / 'src' / 'random_tick_picker.hpp', root / 'src' / 'random_tick_picker.hpp')
    print('Patched Afterflow! Added F6 random stage and editable Random tick options.')
    print('Originals backed up to src/main.cpp.bak and mod.json.bak.')
    print('Rebuild with your Geode SDK to generate the .geode mod file.')


if __name__ == '__main__':
    main()
