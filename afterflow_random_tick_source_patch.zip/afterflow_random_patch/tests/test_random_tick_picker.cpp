#include "../src/random_tick_picker.hpp"
#include <algorithm>
#include <cassert>
#include <vector>

int main() {
    using afterflow_random::parseTickOptions;
    using afterflow_random::drawTick;
    assert((parseTickOptions("4,2,0") == std::vector<int>{4,2,0}));
    assert((parseTickOptions(" 16 , 32 ,16 ") == std::vector<int>{16,32}));
    assert((parseTickOptions("garbage, -1, 241, 4x") == std::vector<int>{2,4,0}));
    assert((parseTickOptions("0") == std::vector<int>{0}));
    assert((parseTickOptions("0,240") == std::vector<int>{0,240}));
    for (int i = 0; i < 500; ++i) {
        int value = drawTick("4,2,0");
        assert(value == 4 || value == 2 || value == 0);
        assert(drawTick("32") == 32);
    }
}
