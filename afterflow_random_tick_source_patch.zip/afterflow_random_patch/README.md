# Afterflow v2.1.6 — random tick stage (source patch)

**This is a source-code patch, NOT a compiled .geode mod.** The supplied .geode contains compiled Windows/macOS binaries. Rebuilding requires the Geode SDK and Geometry Dash bindings, which are not available in this environment. Do not place this patch ZIP directly into `geode/mods`.

This patch is intended for the original Afterflow v2.1.6 source at https://github.com/afterflow-gd/afterflow (MIT licensed). It preserves F6 stage cycling and adds a **ninth stage: Random per click** after the existing `off` stage. The other 8 stages are untouched.

## Install / build

1. Download or clone the Afterflow v2.1.6 source (the `src/main.cpp`, `mod.json`, and `CMakeLists.txt` project directory).
2. Extract this patch archive somewhere else.
3. Run `python apply_random_stage.py /path/to/afterflow-source` (on Windows, use `py apply_random_stage.py C:\\path\\to\\afterflow`).
4. Build the modified source using the original project's build instructions (`geode build -p windows` when cross compiling, or `geode build` on Windows/macOS). It requires Geode SDK 5.11.2 and GD 2.2081 bindings.
5. Put the newly compiled `.geode` in your game's `geode/mods` and restart.

## In game

- **Geode → Mods → Afterflow → Settings → Random tick options**: enter comma-separated values like `4,2,0`, or `16,32`. You can edit these values at any time. The set persists in Geode's settings.
- Press **F6** until Afterflow is on **Random per click**. F6 still cycles the original seven buffered stages and raw-input `off` stage. You can rebind F6 as before.
- On each new *press*, it independently picks a uniformly random option from the list. The chosen value stays for that press and its release. It uses the same tick value for wave and all other modes.
- `0` means **prediction off** (raw input) for that press and release. Unusable/invalid entries are ignored; if the entire list is invalid, the fallback is `2,4,0`.
- Supported values: 0–240, though very large prediction windows may impact performance. Duplicate values are ignored. A repeated random choice is allowed.
- No in-level indicator/overlay is added; the currently selected stage appears only in the existing terminal log when F6 is pressed.

**Important:** This modifies input behavior and is still a gameplay cheat. It has not been runtime-tested in Geometry Dash; the picker code has unit tests in `tests/`.

## Test the picker independently

`c++ -std=c++17 -Isrc tests/test_random_tick_picker.cpp -o /tmp/afterflow-random-test && /tmp/afterflow-random-test`

## Revert

Restore the original source backups (`src/main.cpp.bak` and `mod.json.bak`), remove `src/random_tick_picker.hpp`, and rebuild.
